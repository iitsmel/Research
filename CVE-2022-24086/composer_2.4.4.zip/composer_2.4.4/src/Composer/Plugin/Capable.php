<?php declare(strict_types=1);











namespace Composer\Plugin;








interface Capable
{


















public function getCapabilities();
}
