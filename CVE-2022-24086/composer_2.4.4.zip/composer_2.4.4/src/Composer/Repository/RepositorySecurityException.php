<?php declare(strict_types=1);











namespace Composer\Repository;






class RepositorySecurityException extends \Exception
{
}
