<?php declare(strict_types=1);











namespace Composer\EventDispatcher;













interface EventSubscriberInterface
{


















public static function getSubscribedEvents();
}
